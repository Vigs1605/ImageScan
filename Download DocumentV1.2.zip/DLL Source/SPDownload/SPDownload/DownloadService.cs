﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;
using SPDownload.LogOperation;
using Newtonsoft.Json;
using System.Security;
using System.Net;
using System.Net.Http;
using Newtonsoft.Json.Linq;

namespace SPDownload
{
   public class DownloadService : BaseSPOperation
    {
        private string webUrl = string.Empty;
        private string userName = string.Empty;
        private string password = string.Empty;
        public DownloadService(string webUrl, string userName, string password)
          : base(webUrl, userName, password)
        {

            this.webUrl = webUrl;
            this.userName = userName;
            this.password = password;
        }



        /// <summary>
        /// Search Document across Site level using Search Query in SP Online
        /// </summary>
        /// <param name="KeywordSearch"></param>
        /// <returns>bool object</returns>
        public bool DownLoadDocument(string KeywordSearch, string destinationFolder)
        {
            bool bResult = false;
            SecureString securePassword = ConvertToSecureString(password);
            SharePointOnlineCredentials cred;
            try
            {
                cred = new SharePointOnlineCredentials(userName, securePassword);
            }
            catch (Exception ex)
            {
                LogManager.LogError(386, ex, string.Format("An error occurred for authentication of user name : {0}", userName));
                throw ex;
            }

            string queryMetadata = string.Empty;
            string queryfileName = string.Empty;

            string query = "DlcDocId:" + KeywordSearch.Trim() + "";

            //  query += ")";

            string url = webUrl + "/_api/search/query?querytext='" + query + "'&selectproperties='Filename,Path,ModifiedOWSDate,ModifiedById,CreatedOWSDate,AuthorOWSUser'&clienttype='ContentSearchRegular'";

            var result = GetRecords(cred, url);


            var JSONObject = JObject.Parse(result.Content.ReadAsStringAsync().Result)["PrimaryQueryResult"]["RelevantResults"]["Table"]["Rows"][0]["Cells"].ToString();

           
                //Converting JSON to dynamic object
                dynamic SearchedItems = JsonConvert.DeserializeObject(JSONObject.ToString());

            string SearchedfileName = string.Empty;
            string SearchedfilePath = string.Empty;
            foreach (var SearchVal in SearchedItems)
            {
                if(SearchVal.Key.Value == "Filename")
                {
                    SearchedfileName = SearchVal.Value.Value;
                }

                if (SearchVal.Key.Value == "Path")
                {
                    SearchedfilePath = SearchVal.Value.Value;
                }
            }

            if (!string.IsNullOrEmpty(SearchedfilePath))
            {
                var absoluteToRelative = new Uri(SearchedfilePath);

                using (FileInformation fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(Context, absoluteToRelative.LocalPath.ToString()))
                {
                    // Combine destination folder with filename -- don't concatenate
                    // it's just wrong!
                    var filePath = Path.Combine(destinationFolder, SearchedfileName);

                    // Erase existing files, cause that's how I roll
                    if (System.IO.File.Exists(filePath))
                    {
                        System.IO.File.Delete(filePath);
                    }

                    // Create the file
                    using (var fileStream = System.IO.File.Create(filePath))
                    {
                        fileInfo.Stream.CopyTo(fileStream);
                        bResult = true;
                    }
                }
            }

    

            return bResult;

        }


        private HttpResponseMessage GetRecords(SharePointOnlineCredentials credential, string url)
        {
            var data1 = "";
            try
            {
                using (var handler = new HttpClientHandler() { Credentials = credential })
                {
                    //Get authentication cookie
                    Uri uri = new Uri(url);
                    handler.CookieContainer.SetCookies(uri, credential.GetAuthenticationCookie(uri));

                    //Invoke REST API 
                    using (var client = new HttpClient(handler))
                    {
                        client.DefaultRequestHeaders.Accept.Clear();
                        client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                        var content = new StringContent(JsonConvert.SerializeObject(data1), Encoding.UTF8, "application/json");
                        System.Net.Http.HttpResponseMessage response = client.GetAsync(url).Result;
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                LogManager.LogError(460, ex, "An error occurred in HttpClientHandler");
                throw ex;
            }

        }


        private SecureString ConvertToSecureString(string password)
        {
            var securePassword = new SecureString();

            try
            {
                if (password == null)

                    throw new ArgumentNullException("password");

                foreach (char c in password)

                    securePassword.AppendChar(c);

                securePassword.MakeReadOnly();
            }
            catch (Exception ex)
            {
                //LogManager.LogError(56, ex, String.Format("An error occurred while converting Password to secure string"));
                throw ex;
            }

            return securePassword;
        }
    }
}
