﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;
using System.Security;
using SPDownload.LogOperation;
using Newtonsoft.Json;
using System.Xml.Linq;

namespace SPDownload
{
    public abstract class BaseSPOperation : IDisposable
    {
        protected static ClientContext Context;

        
        /// <summary>
        /// Create one time SP Context using User Credentials
        /// </summary>
        /// <param name="webUrl"></param>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        protected BaseSPOperation(string webUrl, string userName, string password)
        {
            try
            {
                using (Context = new ClientContext(webUrl))
                {
                    SecureString securePassword = _ConvertToSecureString(password);
                    Context.Credentials = new SharePointOnlineCredentials(userName, securePassword);
                    //Context.RequestTimeout = 1000 * 60 * 3; // 3min time out
                    Web spWeb = Context.Web;
                    Context.Load(spWeb, w => w.Title, w => w.RegionalSettings);
                    Context.ExecuteQuery();
                    LogManager.LogInfo(29, String.Format("SP Context object Created for SiteUrl : {0}", webUrl));
                }
            }
            catch (Exception ex)
            {
                LogManager.LogError(34, ex, String.Format("An error occurred while creating SP Context : {0}", webUrl));
            }
        }

        private SecureString _ConvertToSecureString(string password)
        {
            var securePassword = new SecureString();
            try
            {
                if (password == null)
                    throw new ArgumentNullException("password");

                foreach (char c in password)
                    securePassword.AppendChar(c);

                securePassword.MakeReadOnly();
            }
            catch (Exception ex)
            {
                LogManager.LogError(56, ex, String.Format("An error occurred while converting Password to secure string"));
            }
            return securePassword;
        }

        public void Dispose()
        {
            if (Context == null) return;
            Context.Dispose();
            Context = null;
        }

    


        private Dictionary<string, string> ParseSchemaXml(string schemaXml)
        {
            var properties = new Dictionary<string, string>();
            var xdoc = XDocument.Parse(schemaXml);
            var attributes = xdoc.Descendants("Field").Attributes();
            foreach (var attr in attributes)
            {
                if (!properties.ContainsKey(attr.Name.LocalName))
                    properties.Add(attr.Name.LocalName, attr.Value);
            }
            return properties;
        }



      



    }
}
