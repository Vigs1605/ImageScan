﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Diagnostics;
using System.Data;
using System.IO;

namespace SPDownload.LogOperation
{
    public static class LogManager
    {
        public static bool isLogInfo;
         

        internal static string GetErroMessage(Exception ex)
        {
            if (ex == null)
            {
                return string.Empty;
            }
            return "msg=" + ex.Message + " ~ innerEx=" + ex.InnerException + " ~ stacktrace=" + ex.StackTrace;
        }

        public static void LogError(int eventId, Exception ex, string additionalInfo)
        {
            try
            {

                WriteToErrorLogTable(eventId, LogTypes.Error, GetErroMessage(ex) + " ~ additional=" + additionalInfo);

            }
            catch
            {
                //as it is error handler 
            }

        }

        public static void LogWarning(int eventId, Exception ex, string additionalInfo)
        {
            try
            {

                WriteToErrorLogTable(eventId, LogTypes.Warning, GetErroMessage(ex) + " ~ additional=" + additionalInfo);

            }
            catch
            {
                //as it is error handler 
            }

        }

        public static void LogInfo(int eventId, string message)
        {
            try
            {
                if (isLogInfo)
                    WriteToErrorLogTable(eventId, LogTypes.Info, message);

            }
            catch
            {
                //as it is error handler 
            }

        }


        internal static void WriteToErrorLogTable(int eventId, LogTypes logType, string desc)
        {
            

             StreamWriter log;
            string filename = "\\Log_SharePointDLL" + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
            string filepath = System.IO.Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath) + filename;
            
            if (!File.Exists(filepath))
            {

                log = new StreamWriter(filepath);
            }
            else
            {
                log = File.AppendText(filepath);
            }

            log.WriteLine("Data Time: " + DateTime.Now + " ; " + "Event ID: " + eventId + " ; " + "Log Type: " + logType + " ; " + "Description :" + desc);

         

            log.Close();

   
        }

        public enum LogTypes
        {
            Error, Warning, Info
        }
    }
}
