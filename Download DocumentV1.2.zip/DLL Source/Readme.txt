
//To call DownLoadDocument, instantiate DownloadService Class by passing Site Url, 
 DownloadService ser = new DownloadService("https://tsinfo.sharepoint.com/sites/Guru", "preeti@tsinfo.onmicrosoft.com", "ESP@56789");
 
 //DownLoadDocument accept string input parameters as DocumentID and Local system Download Path and Output will be a Boolean value, True - Downloaded, False- Error in Destination Path/Document ID doesn't exist
 // System.IO.Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath indicates the file download in current running application
   var result = ser.DownLoadDocument("SPDLL-2063013555-5", System.IO.Path.GetDirectoryName(System.Windows.Forms.Application.ExecutablePath));